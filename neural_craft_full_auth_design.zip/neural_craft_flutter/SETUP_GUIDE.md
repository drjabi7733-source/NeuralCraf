# دليل الإعداد الكامل - NeuralCraft

## المرحلة الأولى: تثبيت Flutter

### على Windows

1. قم بتحميل Flutter SDK من: https://flutter.dev/docs/get-started/install/windows

2. قم بفك ضغط الملف في مكان آمن (مثلاً: `C:\flutter`)

3. أضف Flutter إلى متغيرات البيئة:
   - افتح "System Environment Variables"
   - أضف `C:\flutter\bin` إلى PATH

4. تحقق من التثبيت:
```bash
flutter doctor
```

### على macOS

```bash
# استخدام Homebrew
brew install flutter

# أو تحميل يدوي من https://flutter.dev/docs/get-started/install/macos
```

### على Linux

```bash
# تحميل Flutter
git clone https://github.com/flutter/flutter.git -b stable

# إضافة Flutter إلى PATH
export PATH="$PATH:`pwd`/flutter/bin"

# التحقق من التثبيت
flutter doctor
```

## المرحلة الثانية: إعداد Android SDK

### على Windows

1. قم بتحميل Android Studio من: https://developer.android.com/studio

2. أثناء التثبيت، تأكد من تثبيت:
   - Android SDK
   - Android SDK Platform-Tools
   - Android Emulator

3. قبول الترخيصات:
```bash
flutter doctor --android-licenses
```

### على macOS و Linux

```bash
flutter doctor --android-licenses
```

## المرحلة الثالثة: إعداد المشروع

### 1. استخراج المشروع

```bash
# فك ضغط الملف
unzip neural_craft_flutter.zip
cd neural_craft_flutter
```

### 2. تثبيت الاعتماديات

```bash
flutter pub get
```

### 3. التحقق من الإعداد

```bash
flutter doctor
```

تأكد من أن جميع المتطلبات مكتملة (✓).

## المرحلة الرابعة: تشغيل التطبيق

### على جهاز محاكي

```bash
# إنشاء محاكي Android
flutter emulators --create --name neural_craft

# تشغيل المحاكي
flutter emulators --launch neural_craft

# تشغيل التطبيق
flutter run
```

### على جهاز حقيقي

1. قم بتوصيل جهازك بالكمبيوتر عبر USB

2. فعّل وضع المطور على جهازك:
   - اذهب إلى الإعدادات
   - ابحث عن "رقم الإصدار" واضغط عليه 7 مرات
   - ستظهر خيارات المطور

3. تشغيل التطبيق:
```bash
flutter run
```

## المرحلة الخامسة: بناء APK

### بناء APK للإصدار (Release)

هذا هو الملف الذي ستستخدمه لنشر التطبيق:

```bash
flutter build apk --release
```

سيتم إنشاء الملف في:
```
build/app/outputs/flutter-apk/app-release.apk
```

### بناء APK للاختبار (Debug)

```bash
flutter build apk --debug
```

سيتم إنشاء الملف في:
```
build/app/outputs/flutter-apk/app-debug.apk
```

### بناء APK متعدد المعمارات

```bash
flutter build apk --split-per-abi --release
```

سيتم إنشاء ملفات منفصلة لكل معمارية:
- `app-armeabi-v7a-release.apk`
- `app-arm64-v8a-release.apk`
- `app-x86_64-release.apk`

## المرحلة السادسة: بناء AAB (Android App Bundle)

للنشر على Google Play Store:

```bash
flutter build appbundle --release
```

سيتم إنشاء الملف في:
```
build/app/outputs/bundle/release/app-release.aab
```

## حل المشاكل الشائعة

### مشكلة: "flutter: command not found"

**الحل:**
```bash
# تأكد من إضافة Flutter إلى PATH
export PATH="$PATH:/path/to/flutter/bin"

# أو أضفه بشكل دائم في ~/.bashrc أو ~/.zshrc
```

### مشكلة: "Android SDK not found"

**الحل:**
```bash
flutter config --android-sdk /path/to/android/sdk
```

### مشكلة: "Gradle build failed"

**الحل:**
```bash
# نظف المشروع
flutter clean

# أعد تثبيت الاعتماديات
flutter pub get

# حاول البناء مرة أخرى
flutter build apk --release
```

### مشكلة: "No connected devices"

**الحل:**
```bash
# تحقق من الأجهزة المتصلة
flutter devices

# إذا لم يظهر جهازك:
# 1. تأكد من توصيل USB
# 2. فعّل وضع المطور
# 3. اسمح بتصحيح الأخطاء عبر USB
```

## تخصيص التطبيق

### تغيير اسم التطبيق

عدّل في `android/app/src/main/AndroidManifest.xml`:

```xml
<application
    android:label="اسم التطبيق الجديد"
    ...
/>
```

### تغيير معرّف الحزمة

عدّل في `android/app/build.gradle`:

```gradle
applicationId "com.yourcompany.yourapp"
```

### تغيير الأيقونة

ضع أيقونتك في:
```
android/app/src/main/res/mipmap-*/ic_launcher.png
```

### تغيير لون الموضوع

عدّل في `lib/utils/theme_helper.dart`:

```dart
static const Color primaryColor = Color(0xFFYourColor);
```

## نصائح مهمة

1. **قبل البناء للإصدار:**
   - اختبر التطبيق جيداً على جهاز حقيقي
   - تأكد من جميع الأذونات في `AndroidManifest.xml`
   - اختبر جميع الميزات

2. **لتقليل حجم APK:**
```bash
flutter build apk --release --split-per-abi
```

3. **لتحسين الأداء:**
   - استخدم `--release` بدلاً من `--debug`
   - قلل حجم الصور
   - استخدم lazy loading للبيانات

4. **للنشر على Google Play:**
   - أنشئ حساب Google Play Developer
   - وقّع APK بشهادة توقيع خاصة
   - أرفع AAB بدلاً من APK

## الخطوات التالية

بعد بناء APK بنجاح:

1. **اختبر التطبيق:**
   - ثبت APK على جهاز حقيقي
   - اختبر جميع الشاشات والميزات

2. **نشر التطبيق:**
   - على Google Play Store
   - على متاجر بديلة مثل AppGallery

3. **جمع الملاحظات:**
   - اطلب من المستخدمين إرسال ملاحظاتهم
   - حسّن التطبيق بناءً على الملاحظات

## المساعدة والدعم

- توثيق Flutter: https://flutter.dev/docs
- منتدى Flutter: https://stackoverflow.com/questions/tagged/flutter
- GitHub Issues: https://github.com/flutter/flutter/issues

---

**تم إنشاؤه بواسطة NeuralCraft - 2026**
