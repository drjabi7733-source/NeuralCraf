import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'screens/home_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/my_projects_screen.dart';
import 'screens/templates_screen.dart';
import 'screens/analytics_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/login_screen.dart';
import 'utils/theme_helper.dart';
import 'utils/auth_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // ملاحظة: يجب تهيئة Firebase هنا بعد إضافة ملفات google-services.json
  // await Firebase.initializeApp();
  runApp(const NeuralCraftApp());
}

class NeuralCraftApp extends StatefulWidget {
  const NeuralCraftApp({super.key});

  @override
  State<NeuralCraftApp> createState() => _NeuralCraftAppState();
}

class _NeuralCraftAppState extends State<NeuralCraftApp> {
  bool isDarkMode = false;
  String currentLanguage = 'ar';
  final AuthService _authService = AuthService();

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  void _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      isDarkMode = prefs.getBool('darkMode') ?? false;
      currentLanguage = prefs.getString('language') ?? 'ar';
    });
  }

  void _toggleTheme() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      isDarkMode = !isDarkMode;
      prefs.setBool('darkMode', isDarkMode);
    });
  }

  void _changeLanguage(String langCode) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      currentLanguage = langCode;
      prefs.setString('language', langCode);
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NeuralCraft',
      locale: Locale(currentLanguage),
      supportedLocales: const [
        Locale('ar'),
        Locale('en'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Cairo',
        brightness: Brightness.light,
        primaryColor: ThemeHelper.primaryColor,
        scaffoldBackgroundColor: ThemeHelper.lightBg,
        cardColor: Colors.white,
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Colors.white,
          selectedItemColor: ThemeHelper.primaryColor,
          unselectedItemColor: Colors.grey,
          selectedLabelStyle: TextStyle(fontFamily: 'Cairo', fontSize: 10, fontWeight: FontWeight.bold),
          unselectedLabelStyle: TextStyle(fontFamily: 'Cairo', fontSize: 10),
          type: BottomNavigationBarType.fixed,
          elevation: 10,
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Cairo',
        brightness: Brightness.dark,
        primaryColor: ThemeHelper.primaryColor,
        scaffoldBackgroundColor: ThemeHelper.darkBg,
        cardColor: ThemeHelper.darkCard,
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: ThemeHelper.darkCard,
          selectedItemColor: ThemeHelper.primaryColor,
          unselectedItemColor: Colors.grey,
          selectedLabelStyle: TextStyle(fontFamily: 'Cairo', fontSize: 10, fontWeight: FontWeight.bold),
          unselectedLabelStyle: TextStyle(fontFamily: 'Cairo', fontSize: 10),
          type: BottomNavigationBarType.fixed,
        ),
      ),
      themeMode: isDarkMode ? ThemeMode.dark : ThemeMode.light,
      home: StreamBuilder<User?>(
        stream: _authService.authStateChanges,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          if (snapshot.hasData) {
            return MainApp(
              onThemeToggle: _toggleTheme,
              onLanguageChange: _changeLanguage,
              isDarkMode: isDarkMode,
            );
          }
          return const LoginScreen();
        },
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MainApp extends StatefulWidget {
  final VoidCallback onThemeToggle;
  final Function(String) onLanguageChange;
  final bool isDarkMode;

  const MainApp({
    super.key,
    required this.onThemeToggle,
    required this.onLanguageChange,
    required this.isDarkMode,
  });

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  int _selectedIndex = 0;
  final AuthService _authService = AuthService();

  late List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      const HomeScreen(),
      const ChatScreen(),
      const MyProjectsScreen(),
      const TemplatesScreen(),
      const AnalyticsScreen(),
      SettingsScreen(
        onLanguageChange: widget.onLanguageChange,
        onThemeToggle: widget.onThemeToggle,
        isDarkMode: widget.isDarkMode,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: (index) {
            HapticFeedback.selectionClick();
            setState(() {
              _selectedIndex = index;
            });
          },
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_rounded),
              label: 'الرئيسية',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.chat_bubble_rounded),
              label: 'المساعد',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.folder_rounded),
              label: 'مشاريعي',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.grid_view_rounded),
              label: 'القوالب',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.bar_chart_rounded),
              label: 'التحليلات',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings_rounded),
              label: 'الإعدادات',
            ),
          ],
        ),
      ),
    );
  }
}
