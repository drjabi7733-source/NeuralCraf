import 'dart:convert';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:http/http.dart' as http;

class AIService {
  // مفاتيح الـ API (يجب وضعها في ملف .env أو إعدادات آمنة في الإنتاج)
  static const String _geminiApiKey = 'YOUR_GEMINI_API_KEY';
  static const String _openAiApiKey = 'YOUR_OPENAI_API_KEY';

  /// المحرك الأساسي: Google Gemini Pro
  Future<String> getResponse(String prompt) async {
    try {
      return await _callGemini(prompt);
    } catch (e) {
      print('Gemini Error: $e. Switching to Backup AI (ChatGPT)...');
      try {
        return await _callChatGPT(prompt);
      } catch (backupError) {
        return 'عذراً، حدث خطأ في كلا المحركين. يرجى المحاولة لاحقاً. الخطأ: $backupError';
      }
    }
  }

  /// استدعاء Google Gemini Pro
  Future<String> _callGemini(String prompt) async {
    final model = GenerativeModel(
      model: 'gemini-pro',
      apiKey: _geminiApiKey,
    );
    
    final content = [Content.text(prompt)];
    final response = await model.generateContent(content);
    
    if (response.text == null || response.text!.isEmpty) {
      throw Exception('Gemini returned empty response');
    }
    
    return response.text!;
  }

  /// استدعاء OpenAI ChatGPT (gpt-4o-mini) كاحتياطي
  Future<String> _callChatGPT(String prompt) async {
    final url = Uri.parse('https://api.openai.com/v1/chat/completions');
    
    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer $_openAiApiKey',
      },
      body: jsonEncode({
        'model': 'gpt-4o-mini',
        'messages': [
          {'role': 'user', 'content': prompt}
        ],
        'temperature': 0.7,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['choices'][0]['message']['content'].toString().trim();
    } else {
      throw Exception('ChatGPT API failed with status: ${response.statusCode}');
    }
  }
}
