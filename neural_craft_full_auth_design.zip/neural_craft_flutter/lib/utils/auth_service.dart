import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  // الحصول على المستخدم الحالي
  User? get currentUser => _auth.currentUser;

  // دفق حالة التوثيق
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // تسجيل الدخول باستخدام جوجل
  Future<UserCredential?> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return null;

      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      return await _auth.signInWithCredential(credential);
    } catch (e) {
      print("Error Google Sign In: $e");
      return null;
    }
  }

  // تسجيل الدخول باستخدام فيسبوك
  Future<UserCredential?> signInWithFacebook() async {
    try {
      final LoginResult result = await FacebookAuth.instance.login();
      if (result.status == LoginStatus.success) {
        final AuthCredential credential = FacebookAuthProvider.credential(result.accessToken!.tokenString);
        return await _auth.signInWithCredential(credential);
      }
      return null;
    } catch (e) {
      print("Error Facebook Sign In: $e");
      return null;
    }
  }

  // تسجيل الدخول باستخدام تويتر (X)
  Future<UserCredential?> signInWithTwitter() async {
    try {
      TwitterAuthProvider twitterProvider = TwitterAuthProvider();
      return await _auth.signInWithProvider(twitterProvider);
    } catch (e) {
      print("Error Twitter Sign In: $e");
      return null;
    }
  }

  // تسجيل الدخول باستخدام مايكروسوفت
  Future<UserCredential?> signInWithMicrosoft() async {
    try {
      MicrosoftAuthProvider microsoftProvider = MicrosoftAuthProvider();
      return await _auth.signInWithProvider(microsoftProvider);
    } catch (e) {
      print("Error Microsoft Sign In: $e");
      return null;
    }
  }

  // تسجيل الدخول برقم الهاتف
  Future<void> verifyPhoneNumber({
    required String phoneNumber,
    required Function(String verificationId) onCodeSent,
    required Function(FirebaseAuthException e) onFailed,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: onFailed,
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  // إكمال تسجيل الدخول برقم الهاتف باستخدام رمز التحقق
  Future<UserCredential?> signInWithPhoneNumber(String verificationId, String smsCode) async {
    try {
      final AuthCredential credential = PhoneAuthProvider.credential(
        verificationId: verificationId,
        smsCode: smsCode,
      );
      return await _auth.signInWithCredential(credential);
    } catch (e) {
      print("Error Phone Sign In: $e");
      return null;
    }
  }

  // تحديث اسم المستخدم (DisplayName)
  Future<void> updateUsername(String username) async {
    try {
      await _auth.currentUser?.updateDisplayName(username);
    } catch (e) {
      print("Error updating username: $e");
    }
  }

  // تسجيل الخروج
  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await FacebookAuth.instance.logOut();
    await _auth.signOut();
  }
}
