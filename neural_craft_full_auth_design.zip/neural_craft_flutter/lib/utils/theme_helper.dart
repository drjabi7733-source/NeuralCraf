import 'package:flutter/material.dart';

class ThemeHelper {
  // الألوان الأساسية المستوحاة من الصورة
  static const Color primaryColor = Color(0xFF6C5CE7); // البنفسجي الأساسي
  static const Color secondaryColor = Color(0xFFA29BFE); // البنفسجي الفاتح
  static const Color accentColor = Color(0xFFFD79A8); // لون وردي خفيف للتنبيهات
  
  static const Color successColor = Color(0xFF00B894);
  static const Color warningColor = Color(0xFFFDCB6E);
  static const Color errorColor = Color(0xFFD63031);
  static const Color infoColor = Color(0xFF0984E3);

  // ألوان الخلفية والبطاقات (Light)
  static const Color lightBg = Color(0xFFF9FAFF); // خلفية مائلة للزرقة خفيفة جداً
  static const Color lightCard = Colors.white;
  static const Color lightText = Color(0xFF2D3436);
  static const Color lightBorder = Color(0xFFEFEFEF);

  // ألوان الخلفية والبطاقات (Dark)
  static const Color darkBg = Color(0xFF1E1E2C);
  static const Color darkCard = Color(0xFF2D2D44);
  static const Color darkText = Colors.white;
  static const Color darkBorder = Color(0xFF3D3D5C);

  // التدرجات اللونية
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primaryColor, Color(0xFF8E78FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient cardGradient = LinearGradient(
    colors: [Color(0xFFF3F0FF), Colors.white],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  // الظلال
  static const List<BoxShadow> softShadow = [
    BoxShadow(
      color: Color(0x0D000000),
      blurRadius: 10,
      offset: Offset(0, 4),
    ),
  ];

  static const List<BoxShadow> accentShadow = [
    BoxShadow(
      color: Color(0x336C5CE7),
      blurRadius: 15,
      offset: Offset(0, 8),
    ),
  ];

  // أقطار الزوايا
  static const double radiusSmall = 10;
  static const double radiusMedium = 15;
  static const double radiusLarge = 20;
  static const double radiusXLarge = 30;

  // المسافات
  static const double spacingSmall = 8;
  static const double spacingMedium = 16;
  static const double spacingLarge = 24;
}
