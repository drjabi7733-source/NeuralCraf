import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/auth_service.dart';
import '../utils/theme_helper.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final AuthService _authService = AuthService();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _otpController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  
  bool _isOtpSent = false;
  String _verificationId = "";
  bool _isLoading = false;

  void _triggerHaptic() {
    HapticFeedback.mediumImpact();
  }

  Future<void> _handleAuthAction(Future<dynamic> Function() authMethod) async {
    _triggerHaptic();
    setState(() => _isLoading = true);
    try {
      final userCredential = await authMethod();
      if (userCredential != null && _usernameController.text.isNotEmpty) {
        await _authService.updateUsername(_usernameController.text);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("حدث خطأ: $e")));
    }
    setState(() => _isLoading = false);
  }

  Future<void> _sendOtp() async {
    if (_phoneController.text.isEmpty) return;
    _triggerHaptic();
    setState(() => _isLoading = true);
    await _authService.verifyPhoneNumber(
      phoneNumber: _phoneController.text,
      onCodeSent: (id) {
        setState(() {
          _verificationId = id;
          _isOtpSent = true;
          _isLoading = false;
        });
      },
      onFailed: (e) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("فشل التحقق: ${e.message}")));
      },
    );
  }

  Future<void> _verifyOtp() async {
    if (_otpController.text.isEmpty) return;
    _triggerHaptic();
    setState(() => _isLoading = true);
    final user = await _authService.signInWithPhoneNumber(_verificationId, _otpController.text);
    if (user != null && _usernameController.text.isNotEmpty) {
      await _authService.updateUsername(_usernameController.text);
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeHelper.lightBg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 30),
              // Logo
              Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: ThemeHelper.primaryColor.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.psychology, size: 60, color: ThemeHelper.primaryColor),
              ),
              const SizedBox(height: 20),
              const Text(
                'مرحباً بك في NeuralCraft',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
              ),
              const Text(
                'سجل دخولك لتبدأ رحلة الإبداع',
                style: TextStyle(color: Colors.grey, fontFamily: 'Cairo', fontSize: 14),
              ),
              const SizedBox(height: 30),

              // Username Field
              _buildTextField(_usernameController, 'اسم المستخدم المفضل', Icons.person_outline),
              const SizedBox(height: 16),

              if (!_isOtpSent) ...[
                _buildTextField(_phoneController, 'رقم الهاتف (مثل +966...)', Icons.phone_android_outlined, keyboardType: TextInputType.phone),
                const SizedBox(height: 20),
                _buildPrimaryButton('إرسال رمز التحقق SMS', _sendOtp),
              ] else ...[
                _buildTextField(_otpController, 'أدخل الرمز المكون من 6 أرقام', Icons.lock_clock_outlined, keyboardType: TextInputType.number),
                const SizedBox(height: 20),
                _buildPrimaryButton('تأكيد الرمز والدخول', _verifyOtp),
                TextButton(
                  onPressed: () => setState(() => _isOtpSent = false),
                  child: const Text('تغيير رقم الهاتف', style: TextStyle(color: ThemeHelper.primaryColor, fontFamily: 'Cairo')),
                ),
              ],

              const SizedBox(height: 25),
              const Row(
                children: [
                  Expanded(child: Divider()),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Text('أو سجل عبر المنصات التالية', style: TextStyle(color: Colors.grey, fontSize: 11, fontFamily: 'Cairo')),
                  ),
                  Expanded(child: Divider()),
                ],
              ),
              const SizedBox(height: 25),

              // Social Login Grid
              Wrap(
                spacing: 20,
                runSpacing: 20,
                alignment: WrapAlignment.center,
                children: [
                  _buildSocialButton(Icons.g_mobiledata, Colors.red, () => _handleAuthAction(_authService.signInWithGoogle)),
                  _buildSocialButton(Icons.facebook, Colors.blue, () => _handleAuthAction(_authService.signInWithFacebook)),
                  _buildSocialButton(Icons.close, Colors.black, () => _handleAuthAction(_authService.signInWithTwitter)), // X icon
                  _buildSocialButton(Icons.window, Colors.blue.shade700, () => _handleAuthAction(_authService.signInWithMicrosoft)),
                ],
              ),
              
              if (_isLoading)
                const Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: CircularProgressIndicator(color: ThemeHelper.primaryColor),
                ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hint, IconData icon, {TextInputType keyboardType = TextInputType.text}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: ThemeHelper.softShadow,
        border: Border.all(color: ThemeHelper.lightBorder),
      ),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        textAlign: TextAlign.right,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(fontSize: 13, color: Colors.grey, fontFamily: 'Cairo'),
          prefixIcon: Icon(icon, color: ThemeHelper.primaryColor, size: 20),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        ),
      ),
    );
  }

  Widget _buildPrimaryButton(String text, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: _isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: ThemeHelper.primaryColor,
          padding: const EdgeInsets.symmetric(vertical: 15),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 2,
        ),
        child: Text(
          text,
          style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
        ),
      ),
    );
  }

  Widget _buildSocialButton(IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: _isLoading ? null : onTap,
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: ThemeHelper.softShadow,
          border: Border.all(color: ThemeHelper.lightBorder),
        ),
        child: Icon(icon, size: 30, color: color),
      ),
    );
  }
}
