import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/theme_helper.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(parent: _controller, curve: Curves.easeIn);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _triggerHaptic() {
    HapticFeedback.lightImpact();
  }

  @override
  Widget build(BuildContext context) {
    bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? ThemeHelper.darkBg : ThemeHelper.lightBg,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                // Header: Profile & Greeting
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: ThemeHelper.primaryColor.withOpacity(0.2), width: 2),
                      ),
                      child: const CircleAvatar(
                        radius: 25,
                        backgroundColor: Colors.white,
                        child: Icon(Icons.person, color: ThemeHelper.primaryColor, size: 30),
                      ),
                    ),
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          'مرحباً بك 👋',
                          style: TextStyle(color: Colors.grey, fontSize: 14, fontFamily: 'Cairo'),
                        ),
                        Text(
                          'ماذا تبني اليوم؟',
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 25),

                // AI Tip Banner
                Container(
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF3F0FF),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: const Color(0xFFE0D9FF)),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.auto_awesome, color: ThemeHelper.primaryColor, size: 20),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'جرب وصف تطبيقك بتفاصيل أكثر للحصول على كود أفضل 💡',
                          textAlign: TextAlign.right,
                          style: TextStyle(fontSize: 13, color: ThemeHelper.primaryColor, fontFamily: 'Cairo'),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Main CTA: Create New App
                GestureDetector(
                  onTap: () {
                    _triggerHaptic();
                  },
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: ThemeHelper.primaryGradient,
                      borderRadius: BorderRadius.circular(25),
                      boxShadow: ThemeHelper.accentShadow,
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.chevron_left, color: Colors.white70),
                        const Spacer(),
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              'إنشاء تطبيق جديد',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Cairo',
                              ),
                            ),
                            Text(
                              'صف فكرتك والذكاء الاصطناعي يبنيها',
                              style: TextStyle(color: Colors.white70, fontSize: 12, fontFamily: 'Cairo'),
                            ),
                          ],
                        ),
                        const SizedBox(width: 15),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: const Icon(Icons.auto_fix_high, color: Colors.white, size: 30),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 30),

                // Quick Actions Section
                const Text(
                  'الإجراءات السريعة',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
                ),
                const SizedBox(height: 15),
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  crossAxisSpacing: 15,
                  mainAxisSpacing: 15,
                  childAspectRatio: 1.1,
                  children: [
                    _buildQuickActionCard(
                      'إنشاء تطبيق',
                      Icons.auto_fix_high,
                      const Color(0xFFEBE9FF),
                      const Color(0xFF6C5CE7),
                    ),
                    _buildQuickActionCard(
                      'المساعد الذكي',
                      Icons.chat_bubble_outline,
                      const Color(0xFFFFE9F0),
                      const Color(0xFFFD79A8),
                    ),
                    _buildQuickActionCard(
                      'القوالب',
                      Icons.grid_view,
                      const Color(0xFFE9FFF3),
                      const Color(0xFF00B894),
                    ),
                    _buildQuickActionCard(
                      'التحليلات',
                      Icons.bar_chart,
                      const Color(0xFFFFF6E9),
                      const Color(0xFFFDCB6E),
                    ),
                  ],
                ),
                const SizedBox(height: 30),

                // Recent Projects Section
                const Text(
                  'آخر المشاريع',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
                ),
                const SizedBox(height: 15),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    border: Border.all(color: ThemeHelper.lightBorder),
                    boxShadow: ThemeHelper.softShadow,
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.lock_outline, size: 40, color: Colors.grey),
                      const SizedBox(height: 15),
                      const Text(
                        'سجّل دخولك',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        'سجّل دخولك لحفظ مشاريعك ومتابعة تقدمك',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey, fontSize: 13, fontFamily: 'Cairo'),
                      ),
                      const SizedBox(height: 20),
                      // Optional: Login Button could go here
                    ],
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActionCard(String title, IconData icon, Color bgColor, Color iconColor) {
    return GestureDetector(
      onTap: () {
        _triggerHaptic();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: ThemeHelper.lightBorder),
          boxShadow: ThemeHelper.softShadow,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(icon, color: iconColor, size: 28),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                fontFamily: 'Cairo',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
