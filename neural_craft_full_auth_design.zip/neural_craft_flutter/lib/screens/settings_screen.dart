import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';

class SettingsScreen extends StatefulWidget {
  final Function(String) onLanguageChange;
  final VoidCallback onThemeToggle;
  final bool isDarkMode;

  const SettingsScreen({
    super.key,
    required this.onLanguageChange,
    required this.onThemeToggle,
    required this.isDarkMode,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final LocalAuthentication auth = LocalAuthentication();
  bool biometricEnabled = false;
  bool notificationsEnabled = true;
  bool hapticFeedbackEnabled = true;

  @override
  void initState() {
    super.initState();
    _checkBiometric();
  }

  void _checkBiometric() async {
    try {
      final canAuthenticateWithBiometrics = await auth.canCheckBiometrics;
      final canAuthenticate = canAuthenticateWithBiometrics || await auth.deviceSupportsFaceID || await auth.deviceSupportsFingerprint;
      setState(() {
        biometricEnabled = canAuthenticate;
      });
    } catch (e) {
      debugPrint('Error checking biometric: $e');
    }
  }

  void _authenticateWithBiometrics() async {
    try {
      final isAuthenticated = await auth.authenticate(
        localizedReason: 'استخدم بصمتك لتأكيد الهوية',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: true,
        ),
      );
      if (isAuthenticated) {
        HapticFeedback.heavyImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم التحقق بنجاح! ✓')),
        );
      }
    } catch (e) {
      debugPrint('Error authenticating: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isDark = Theme.of(context).brightness == Brightness.dark;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              'الإعدادات الفاخرة والمستقبلية',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : Colors.black,
              ),
            ),
          ),
          const SizedBox(height: 15),

          // Authentication Card
          Card(
            color: Theme.of(context).cardColor,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
              side: Border.all(
                color: isDark ? Colors.grey.shade900 : Colors.grey.shade100,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 24,
                        backgroundColor: Theme.of(context).primaryColor.withOpacity(0.1),
                        child: Icon(
                          Icons.security,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'تأمين ومزامنة الحساب الموحد',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: isDark ? Colors.white : Colors.black,
                              ),
                            ),
                            const Text(
                              'لحفظ المشاريع وضمان تفوق الكود الخاص بك بشكل سحابي',
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                  const SizedBox(height: 15),
                  _buildSocialLoginButton(
                    'متابعة باستخدام Google',
                    Icons.g_mobiledata,
                    const Color(0xffea4335),
                  ),
                  _buildSocialLoginButton(
                    'متابعة باستخدام Facebook',
                    Icons.facebook,
                    const Color(0xff1877f2),
                  ),
                  _buildSocialLoginButton(
                    'متابعة برقم الهاتف (SMS)',
                    Icons.phone_android,
                    Colors.green,
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),
          _buildSectionTitle('المظهر والتخصيص'),

          _buildSettingTile(
            context,
            'وضع النيون الليلي (Dark Mode)',
            Icons.dark_mode_outlined,
            Colors.orange,
            trailing: Switch(
              value: widget.isDarkMode,
              onChanged: (v) {
                HapticFeedback.mediumImpact();
                widget.onThemeToggle();
              },
            ),
          ),

          _buildSettingTile(
            context,
            'لغة التطبيق',
            Icons.translate,
            Colors.indigo,
            trailing: DropdownButton<String>(
              dropdownColor: Theme.of(context).cardColor,
              underline: const SizedBox(),
              value: 'ar',
              items: const [
                DropdownMenuItem(value: 'ar', child: Text('العربية')),
                DropdownMenuItem(value: 'en', child: Text('English')),
              ],
              onChanged: (langCode) {
                if (langCode != null) {
                  HapticFeedback.mediumImpact();
                  widget.onLanguageChange(langCode);
                }
              },
            ),
          ),

          const SizedBox(height: 15),
          _buildSectionTitle('الأمان والخصوصية'),

          _buildSettingTile(
            context,
            'المصادقة البيومترية',
            Icons.fingerprint,
            Colors.purple,
            trailing: Switch(
              value: biometricEnabled,
              onChanged: biometricEnabled
                  ? (v) {
                      HapticFeedback.mediumImpact();
                      _authenticateWithBiometrics();
                    }
                  : null,
            ),
          ),

          _buildSettingTile(
            context,
            'تشفير البيانات الكامل',
            Icons.lock,
            Colors.red,
            trailing: Text(
              'مفعّل ✓',
              style: TextStyle(
                color: Colors.green,
                fontWeight: FontWeight.bold,
                fontSize: 11,
              ),
            ),
          ),

          const SizedBox(height: 15),
          _buildSectionTitle('التجربة والأداء'),

          _buildSettingTile(
            context,
            'اهتزازات واجهة المستخدم',
            Icons.vibration,
            Colors.teal,
            trailing: Switch(
              value: hapticFeedbackEnabled,
              onChanged: (v) {
                setState(() => hapticFeedbackEnabled = v);
                HapticFeedback.mediumImpact();
              },
            ),
          ),

          _buildSettingTile(
            context,
            'إشعارات التطبيق',
            Icons.notifications_active,
            Colors.blue,
            trailing: Switch(
              value: notificationsEnabled,
              onChanged: (v) {
                setState(() => notificationsEnabled = v);
                HapticFeedback.mediumImpact();
              },
            ),
          ),

          _buildSettingTile(
            context,
            'محرك التوليد الفوري',
            Icons.bolt,
            Colors.amber,
            trailing: Text(
              'تكامل سحابي ✓',
              style: TextStyle(
                color: Theme.of(context).primaryColor,
                fontWeight: FontWeight.bold,
                fontSize: 11,
              ),
            ),
          ),

          const SizedBox(height: 15),
          _buildSectionTitle('حول التطبيق'),

          _buildSettingTile(
            context,
            'إصدار التطبيق',
            Icons.info,
            Colors.cyan,
            trailing: const Text(
              'v1.0.0',
              style: TextStyle(
                color: Colors.grey,
                fontWeight: FontWeight.bold,
                fontSize: 11,
              ),
            ),
          ),

          _buildSettingTile(
            context,
            'سياسة الخصوصية',
            Icons.privacy_tip,
            Colors.pink,
          ),

          _buildSettingTile(
            context,
            'شروط الاستخدام',
            Icons.description,
            Colors.brown,
          ),

          const SizedBox(height: 25),
          Center(
            child: Text(
              'NeuralCraft Pro - جيل الواجهات العصبي المتكامل 2026',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 15),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
      child: Text(
        title,
        style: const TextStyle(
          color: Colors.grey,
          fontSize: 12,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildSettingTile(
    BuildContext context,
    String title,
    IconData icon,
    Color iconBg, {
    Widget? trailing,
  }) {
    bool isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: isDark ? Colors.grey.shade900 : Colors.grey.shade100,
        ),
      ),
      child: ListTile(
        onTap: () => HapticFeedback.lightImpact(),
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: iconBg.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: iconBg, size: 20),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 14,
            color: isDark ? Colors.white : Colors.black,
          ),
        ),
        trailing: trailing,
      ),
    );
  }

  Widget _buildSocialLoginButton(
    String text,
    IconData icon,
    Color color,
  ) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          elevation: 0,
          minimumSize: const Size(double.infinity, 44),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: () => HapticFeedback.mediumImpact(),
        icon: Icon(icon, color: Colors.white, size: 20),
        label: Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
