# NeuralCraft - تطبيق بناء التطبيقات بالذكاء الاصطناعي

تطبيق Flutter احترافي وحديث لبناء التطبيقات باستخدام الذكاء الاصطناعي. يتضمن واجهة مستخدم جميلة وميزات متقدمة مثل المحادثة الذكية وإدارة المشاريع والتحليلات.

## الميزات الرئيسية

- **واجهة مستخدم حديثة**: تصميم احترافي مع دعم الوضع الليلي والفاتح
- **محادثة ذكية**: محرر أكواد ذكي مع دعم الذكاء الاصطناعي
- **إدارة المشاريع**: إنشاء وإدارة المشاريع بسهولة
- **مكتبة القوالب**: أكثر من 50 قالب جاهز للاستخدام
- **التحليلات المتقدمة**: تتبع أداء التطبيقات في الوقت الفعلي
- **المصادقة البيومترية**: أمان عالي مع دعم البصمة والتعرف على الوجه
- **دعم اللغات**: دعم كامل للعربية والإنجليزية
- **تأثيرات اهتزاز**: ملاحظات حسية محسّنة

## المتطلبات

- Flutter SDK 3.0.0 أو أحدث
- Dart SDK 3.0.0 أو أحدث
- Android SDK (للبناء على Android)
- Xcode (للبناء على iOS)

## التثبيت

### 1. استنساخ المشروع

```bash
git clone <repository-url>
cd neural_craft_flutter
```

### 2. تثبيت الاعتماديات

```bash
flutter pub get
```

### 3. تشغيل التطبيق

```bash
flutter run
```

## بناء APK

### بناء APK للإصدار

```bash
flutter build apk --release
```

سيتم إنشاء ملف APK في: `build/app/outputs/flutter-apk/app-release.apk`

### بناء APK للاختبار

```bash
flutter build apk --debug
```

## بناء AAB (Android App Bundle)

```bash
flutter build appbundle --release
```

## هيكل المشروع

```
lib/
├── main.dart                 # نقطة الدخول الرئيسية
├── screens/                  # شاشات التطبيق
│   ├── home_screen.dart
│   ├── chat_screen.dart
│   ├── my_projects_screen.dart
│   ├── templates_screen.dart
│   ├── analytics_screen.dart
│   └── settings_screen.dart
├── widgets/                  # المكونات المخصصة
│   └── custom_widgets.dart
└── utils/                    # أدوات مساعدة
    └── theme_helper.dart
```

## الاعتماديات الرئيسية

- **flutter_localizations**: دعم التعريب والترجمة
- **local_auth**: المصادقة البيومترية
- **google_sign_in**: تسجيل الدخول عبر Google
- **flutter_facebook_auth**: تسجيل الدخول عبر Facebook
- **shared_preferences**: تخزين البيانات المحلية
- **provider**: إدارة الحالة
- **http**: طلبات HTTP

## التكوين

### تغيير لون الموضوع الأساسي

عدّل اللون الأساسي في `lib/utils/theme_helper.dart`:

```dart
static const Color primaryColor = Color(0xFF6366F1);
```

### تغيير اسم التطبيق

عدّل اسم التطبيق في `android/app/src/main/AndroidManifest.xml`:

```xml
<application
    android:label="اسم التطبيق الجديد"
    ...
/>
```

## الأمان

- تشفير كامل للبيانات
- دعم المصادقة البيومترية
- استخدام HTTPS لجميع الاتصالات
- عدم تخزين كلمات المرور بشكل مباشر

## المساهمة

نرحب بالمساهمات! يرجى اتباع هذه الخطوات:

1. قم بعمل Fork للمشروع
2. أنشئ فرع للميزة الجديدة (`git checkout -b feature/AmazingFeature`)
3. قم بالتزام التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. ادفع إلى الفرع (`git push origin feature/AmazingFeature`)
5. افتح Pull Request

## الترخيص

هذا المشروع مرخص تحت MIT License - انظر ملف LICENSE للتفاصيل.

## الدعم

للحصول على الدعم والمساعدة، يرجى فتح Issue أو التواصل معنا عبر البريد الإلكتروني.

## الإصدار

الإصدار الحالي: **1.0.0**

## شكر وتقدير

شكراً لاستخدامك NeuralCraft! نتمنى أن يساعدك هذا التطبيق في بناء مشاريعك الرائعة.

---

**NeuralCraft Pro - جيل الواجهات العصبي المتكامل 2026**
